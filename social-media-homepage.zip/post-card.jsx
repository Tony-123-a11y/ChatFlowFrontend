import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal } from "lucide-react"

export default function PostCard({ post }) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={post.user.avatar || "/placeholder.svg"} alt={post.user.name} className="h-10 w-10 rounded-full" />
          <div>
            <h3 className="font-medium text-gray-900">{post.user.name}</h3>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">{post.user.username}</span>
              <span className="text-sm text-gray-400">•</span>
              <span className="text-sm text-gray-500">{post.time}</span>
            </div>
          </div>
        </div>
        <button className="p-2 rounded-full hover:bg-gray-100">
          <MoreHorizontal className="h-5 w-5 text-gray-500" />
        </button>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-gray-800 mb-3">{post.content}</p>
        {post.image && (
          <div className="rounded-lg overflow-hidden">
            <img src={post.image || "/placeholder.svg"} alt="Post" className="w-full h-auto" />
          </div>
        )}
      </div>

      {/* Post Stats */}
      <div className="px-4 py-2 border-t border-gray-100 flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <span>{post.likes}</span>
          <span>likes</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <span>{post.comments}</span>
            <span>comments</span>
          </div>
          <div className="flex items-center gap-1">
            <span>{post.shares}</span>
            <span>shares</span>
          </div>
        </div>
      </div>

      {/* Post Actions */}
      <div className="px-2 py-1 border-t border-gray-100 flex items-center justify-between">
        <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
          <Heart className="h-5 w-5" />
          <span className="text-sm font-medium">Like</span>
        </button>
        <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
          <MessageCircle className="h-5 w-5" />
          <span className="text-sm font-medium">Comment</span>
        </button>
        <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
          <Share2 className="h-5 w-5" />
          <span className="text-sm font-medium">Share</span>
        </button>
        <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
          <Bookmark className="h-5 w-5" />
          <span className="text-sm font-medium">Save</span>
        </button>
      </div>
    </div>
  )
}
