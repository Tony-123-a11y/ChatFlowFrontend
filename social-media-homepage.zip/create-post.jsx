import { ImageIcon, Video, Smile, MapPin } from "lucide-react"

export default function CreatePost() {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <div className="flex gap-3">
        <img src="/placeholder.svg?height=48&width=48" alt="Profile" className="h-10 w-10 rounded-full" />
        <div className="flex-grow">
          <div className="w-full px-4 py-2.5 bg-gray-100 rounded-full text-gray-500 cursor-pointer hover:bg-gray-200 transition-colors">
            What's on your mind?
          </div>

          <div className="flex justify-between mt-3">
            <button className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-purple-600 transition-colors">
              <ImageIcon className="h-5 w-5" />
              <span>Photo</span>
            </button>
            <button className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-purple-600 transition-colors">
              <Video className="h-5 w-5" />
              <span>Video</span>
            </button>
            <button className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-purple-600 transition-colors">
              <Smile className="h-5 w-5" />
              <span>Feeling</span>
            </button>
            <button className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-purple-600 transition-colors">
              <MapPin className="h-5 w-5" />
              <span>Location</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
