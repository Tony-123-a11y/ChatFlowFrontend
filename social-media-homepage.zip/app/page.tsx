import Homepage from "../homepage"

export default function Page() {
  return <Homepage />
}
