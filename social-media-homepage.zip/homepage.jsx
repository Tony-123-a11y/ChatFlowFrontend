import SidebarNavigation from "./sidebar-navigation"
import Feed from "./feed"
import TrendingSidebar from "./trending-sidebar"
import Header from "./header"

export default function Homepage() {
  return (
    <div className="bg-gray-50 min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-4 flex gap-6">
        {/* Left Sidebar - Navigation */}
        <div className="hidden lg:block w-64 flex-shrink-0">
          <SidebarNavigation />
        </div>

        {/* Main Content - Feed */}
        <div className="flex-grow max-w-2xl">
          <Feed />
        </div>

        {/* Right Sidebar - Trending */}
        <div className="hidden xl:block w-80 flex-shrink-0">
          <TrendingSidebar />
        </div>
      </div>
    </div>
  )
}
