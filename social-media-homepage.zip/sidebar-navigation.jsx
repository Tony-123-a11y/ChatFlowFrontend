import { Home, User, Users, Bookmark, Settings, HelpCircle, LogOut } from "lucide-react"

export default function SidebarNavigation() {
  const menuItems = [
    { icon: <Home className="h-6 w-6" />, label: "Home", active: true },
    { icon: <User className="h-6 w-6" />, label: "Profile" },
    { icon: <Users className="h-6 w-6" />, label: "Friends" },
    { icon: <Bookmark className="h-6 w-6" />, label: "Saved" },
    { icon: <Settings className="h-6 w-6" />, label: "Settings" },
    { icon: <HelpCircle className="h-6 w-6" />, label: "Help Center" },
  ]

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 sticky top-20">
      <nav className="space-y-1">
        {menuItems.map((item, index) => (
          <a
            key={index}
            href="#"
            className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
              item.active
                ? "bg-gradient-to-r from-purple-50 to-blue-50 text-purple-600 font-medium"
                : "text-gray-700 hover:bg-gray-50"
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
            {item.active && <div className="w-1.5 h-1.5 rounded-full bg-purple-600 ml-auto"></div>}
          </a>
        ))}
      </nav>

      <div className="border-t border-gray-200 my-4"></div>

      <a
        href="#"
        className="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
      >
        <LogOut className="h-6 w-6" />
        <span>Logout</span>
      </a>

      <div className="mt-8 p-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg">
        <h3 className="font-medium text-purple-800 mb-2">Upgrade to Pro</h3>
        <p className="text-sm text-purple-700 mb-3">Get exclusive features and priority support</p>
        <button className="w-full py-2 px-4 bg-gradient-to-r from-purple-600 to-blue-500 text-white rounded-lg font-medium hover:opacity-90 transition-opacity">
          Upgrade Now
        </button>
      </div>
    </div>
  )
}
