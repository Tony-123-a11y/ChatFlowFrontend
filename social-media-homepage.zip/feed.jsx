import CreatePost from "./create-post"
import PostCard from "./post-card"

export default function Feed() {
  const posts = [
    {
      id: 1,
      user: {
        name: "Emma Thompson",
        username: "@emmathompson",
        avatar: "/placeholder.svg?height=48&width=48",
      },
      content:
        "Just finished my latest design project! So excited to share it with everyone. What do you think? #design #uxdesign",
      image: "/placeholder.svg?height=400&width=600",
      time: "2 hours ago",
      likes: 142,
      comments: 28,
      shares: 12,
    },
    {
      id: 2,
      user: {
        name: "Alex Johnson",
        username: "@alexj",
        avatar: "/placeholder.svg?height=48&width=48",
      },
      content:
        "Beautiful day for a hike! Nature always helps me clear my mind and find new inspiration. 🏞️ #outdoors #nature",
      image: "/placeholder.svg?height=400&width=600",
      time: "4 hours ago",
      likes: 89,
      comments: 14,
      shares: 5,
    },
    {
      id: 3,
      user: {
        name: "Tech Insights",
        username: "@techinsights",
        avatar: "/placeholder.svg?height=48&width=48",
      },
      content:
        "Breaking: New AI advancements are changing how we approach web development. Here are the top 5 tools you should be using in 2023. #AI #webdev #technology",
      time: "6 hours ago",
      likes: 215,
      comments: 42,
      shares: 31,
    },
  ]

  return (
    <div className="space-y-4">
      <CreatePost />

      {/* Stories */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h2 className="font-medium text-gray-800 mb-3">Stories</h2>
        <div className="flex gap-3 overflow-x-auto pb-2">
          <div className="flex-shrink-0 w-20">
            <div className="relative w-20 h-20 rounded-xl bg-gradient-to-r from-purple-200 to-blue-200 flex items-center justify-center">
              <div className="absolute inset-0.5 bg-white rounded-lg flex items-center justify-center">
                <span className="text-2xl text-purple-500">+</span>
              </div>
            </div>
            <p className="text-xs text-center mt-1 text-gray-700">Add Story</p>
          </div>

          {[1, 2, 3, 4, 5].map((item) => (
            <div key={item} className="flex-shrink-0 w-20">
              <div className="relative w-20 h-20">
                <img
                  src={`/placeholder.svg?height=80&width=80&text=Story${item}`}
                  alt="Story"
                  className="w-full h-full object-cover rounded-xl"
                />
                <div className="absolute top-1 left-1 w-6 h-6 rounded-full border-2 border-white overflow-hidden">
                  <img src="/placeholder.svg?height=24&width=24" alt="User" className="w-full h-full object-cover" />
                </div>
              </div>
              <p className="text-xs text-center mt-1 text-gray-700">User {item}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Posts */}
      <div className="space-y-4">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  )
}
