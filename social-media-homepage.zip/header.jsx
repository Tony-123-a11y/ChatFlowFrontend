import { Search, Bell, MessageSquare, Menu } from "lucide-react"

export default function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center">
          <button className="lg:hidden mr-2">
            <Menu className="h-6 w-6 text-gray-600" />
          </button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 text-transparent bg-clip-text">
            SocialHub
          </h1>
        </div>

        {/* Search */}
        <div className="hidden md:flex relative max-w-md w-full mx-4">
          <input
            type="text"
            placeholder="Search..."
            className="w-full py-2 pl-10 pr-4 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>

        {/* User Actions */}
        <div className="flex items-center gap-4">
          <button className="p-2 rounded-full hover:bg-gray-100">
            <Bell className="h-6 w-6 text-gray-600" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100">
            <MessageSquare className="h-6 w-6 text-gray-600" />
          </button>
          <div className="flex items-center">
            <img
              src="/placeholder.svg?height=40&width=40"
              alt="Profile"
              className="h-10 w-10 rounded-full border-2 border-purple-500"
            />
          </div>
        </div>
      </div>
    </header>
  )
}
